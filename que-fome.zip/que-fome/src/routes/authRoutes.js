const router = require("express").Router();
const c      = require("../controllers/authController");
const { requireAuth } = require("../middlewares/authMiddleware");

router.post("/register",        c.register);
router.post("/login",           c.login);
router.post("/forgot-password", c.forgotPassword);
router.get("/me",  requireAuth, c.me);

module.exports = router;
