require("dotenv").config();
const db = require("C:\Users\gusta\OneDrive\Documentos\Catolica\Que fome Atempt2\SQL.sql");

async function migrate() {
  const c = await db.getConnection();
  try {
    await c.query(`
      CREATE TABLE IF NOT EXISTS usuario (
        id_usuario   INT AUTO_INCREMENT PRIMARY KEY,
        nome_usuario VARCHAR(100) NOT NULL UNIQUE,
        email        VARCHAR(150) NOT NULL,
        senha        VARCHAR(255) NOT NULL
      )
    `);

    await c.query(`
      CREATE TABLE IF NOT EXISTS receita (
        id_receita       INT AUTO_INCREMENT PRIMARY KEY,
        titulo           VARCHAR(150) NOT NULL,
        descricao        TEXT,
        modo_preparo     TEXT NOT NULL,
        data_publicacao  DATE,
        media_calorica   FLOAT,
        id_usuario_autor INT,
        FOREIGN KEY (id_usuario_autor) REFERENCES usuario(id_usuario)
      )
    `);

    await c.query(`
      CREATE TABLE IF NOT EXISTS ingrediente (
        id_ingrediente       INT AUTO_INCREMENT PRIMARY KEY,
        nome                 VARCHAR(100) NOT NULL,
        calorias_por_unidade FLOAT
      )
    `);

    await c.query(`
      CREATE TABLE IF NOT EXISTS composicao_receita (
        id_receita     INT,
        id_ingrediente INT,
        quantidade     FLOAT NOT NULL,
        unidade_medida VARCHAR(10),
        PRIMARY KEY (id_receita, id_ingrediente),
        FOREIGN KEY (id_receita)     REFERENCES receita(id_receita),
        FOREIGN KEY (id_ingrediente) REFERENCES ingrediente(id_ingrediente)
      )
    `);

    await c.query(`
      CREATE TABLE IF NOT EXISTS comentario (
        id_comentario    INT AUTO_INCREMENT PRIMARY KEY,
        texto_comentario TEXT NOT NULL,
        data_hora        DATETIME,
        id_usuario       INT,
        id_receita       INT,
        FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
        FOREIGN KEY (id_receita) REFERENCES receita(id_receita)
      )
    `);

    await c.query(`
      CREATE TABLE IF NOT EXISTS avaliacao (
        id_usuario     INT,
        id_receita     INT,
        nota           INT CHECK (nota BETWEEN 1 AND 5),
        data_avaliacao DATE,
        PRIMARY KEY (id_usuario, id_receita),
        FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
        FOREIGN KEY (id_receita) REFERENCES receita(id_receita)
      )
    `);

    await c.query(`
      CREATE TABLE IF NOT EXISTS favorito (
        id_usuario    INT,
        id_receita    INT,
        data_marcacao DATE,
        PRIMARY KEY (id_usuario, id_receita),
        FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
        FOREIGN KEY (id_receita) REFERENCES receita(id_receita)
      )
    `);

    console.log("✅ Tabelas criadas com sucesso!");
  } catch (err) {
    console.error("❌ Erro na migration:", err.message);
  } finally {
    c.release();
    process.exit(0);
  }
}

migrate();
