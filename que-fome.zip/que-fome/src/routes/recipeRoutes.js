const router = require("express").Router();
const c      = require("../controllers/recipeController");
const { requireAuth, optionalAuth } = require("../middlewares/authMiddleware");

router.get("/",       optionalAuth, c.index);
router.get("/:id",    optionalAuth, c.show);
router.post("/",      requireAuth,  c.create);
router.delete("/:id", requireAuth,  c.destroy);

module.exports = router;
