const db = require("../config/database");

const Rating = {
  async getForRecipe(id_receita) {
    const [[s]] = await db.query(
      "SELECT AVG(nota) AS media, COUNT(*) AS total FROM avaliacao WHERE id_receita = ?",
      [id_receita]
    );
    return {
      media: s.media ? Number(Number(s.media).toFixed(1)) : null,
      total: s.total,
    };
  },

  async getUserRating(id_usuario, id_receita) {
    const [rows] = await db.query(
      "SELECT nota FROM avaliacao WHERE id_usuario = ? AND id_receita = ?",
      [id_usuario, id_receita]
    );
    return rows[0]?.nota || null;
  },

  async upsert({ id_usuario, id_receita, nota }) {
    await db.query(
      `INSERT INTO avaliacao (id_usuario, id_receita, nota, data_avaliacao)
       VALUES (?, ?, ?, CURDATE())
       ON DUPLICATE KEY UPDATE nota = ?, data_avaliacao = CURDATE()`,
      [id_usuario, id_receita, nota, nota]
    );
  },
};

module.exports = Rating;
