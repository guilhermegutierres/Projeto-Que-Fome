const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host:     process.env.DB_HOST     || "localhost",
  port:     process.env.DB_PORT     || 3306,
  database: process.env.DB_NAME     || "sistema_receitas",
  user:     process.env.DB_USER     || "root",
  password: process.env.DB_PASSWORD || "",
  waitForConnections: true,
  connectionLimit: 10,
});

pool.getConnection()
  .then(c => { console.log("✅ MySQL conectado"); c.release(); })
  .catch(err => console.error("❌ Erro MySQL:", err.message));

module.exports = pool;
