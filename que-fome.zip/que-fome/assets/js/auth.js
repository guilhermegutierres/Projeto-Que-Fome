// ================= LOGIN =================
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value;

    try {
      await apiLogin(email, senha);
      window.location.href = "index.html";
    } catch (err) {
      alert(err.message || "E-mail ou senha inválidos.");
    }
  });
}

// ================= CADASTRO =================
const cadastroForm = document.getElementById("cadastroForm");
if (cadastroForm) {
  cadastroForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const nome           = document.getElementById("nome").value.trim();
    const email          = document.getElementById("email").value.trim();
    const senha          = document.getElementById("senha").value;
    const confirmarSenha = document.getElementById("confirmarSenha").value;

    if (senha !== confirmarSenha) {
      alert("As senhas não coincidem.");
      return;
    }

    try {
      await apiRegister(nome, email, senha);
      await apiLogin(email, senha);
      window.location.href = "index.html";
    } catch (err) {
      alert(err.message || "Erro ao criar conta.");
    }
  });
}

// ================= ESQUECI A SENHA =================
const resetForm = document.getElementById("resetForm");
if (resetForm) {
  resetForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();

    try {
      const data = await apiForgotPassword(email);
      alert(data.message);
      window.location.href = "login.html";
    } catch (err) {
      alert(err.message || "Erro ao enviar e-mail.");
    }
  });
}
