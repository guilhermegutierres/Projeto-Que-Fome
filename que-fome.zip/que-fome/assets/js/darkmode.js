// ================= DARK MODE =================
const darkToggle = document.querySelector(".dark-toggle");
const body       = document.body;

if (localStorage.getItem("qf_dark") === "true") {
  body.classList.remove("light-theme");
  body.classList.add("dark-theme");
  if (darkToggle) darkToggle.querySelector("i").className = "ri-sun-line";
}

if (darkToggle) {
  darkToggle.addEventListener("click", () => {
    const isDark = body.classList.toggle("dark-theme");
    body.classList.toggle("light-theme", !isDark);
    const icon = darkToggle.querySelector("i");
    icon.className = isDark ? "ri-sun-line" : "ri-moon-line";
    localStorage.setItem("qf_dark", isDark);
  });
}
