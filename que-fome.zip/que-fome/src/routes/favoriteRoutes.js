const router = require("express").Router();
const c      = require("../controllers/favoriteController");
const { requireAuth } = require("../middlewares/authMiddleware");

router.use(requireAuth);

router.get("/",              c.index);
router.get("/ids",           c.ids);
router.post("/:recipe_id",   c.add);
router.delete("/:recipe_id", c.remove);

module.exports = router;
