// ================= FAVORITOS =================
const cardsContainer = document.querySelector(".cards");

function buildFavCard(recipe) {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <img src="${recipe.image_url || PLACEHOLDER_IMG}" alt="${recipe.title}">
    <div>
      <h2>${recipe.title}</h2>
      <p>${recipe.description || ""}</p>
      <div class="card-actions">
        <button class="btn" onclick="window.location.href='receita.html?id=${recipe.id}'">Ver receita</button>
        <button class="btn btn-fav active" data-id="${recipe.id}">
          <span class="heart"><i class="ri-heart-fill"></i></span> Remover
        </button>
      </div>
    </div>
  `;

  card.querySelector(".btn-fav").addEventListener("click", async (e) => {
    e.stopPropagation();
    try {
      await apiToggleFavorite(recipe.id, true);
      card.remove();
      if (!document.querySelector(".card")) {
        cardsContainer.innerHTML = "<p style='text-align:center;color:#888'>Nenhum favorito ainda.</p>";
      }
    } catch (err) { alert(err.message); }
  });

  return card;
}

async function loadFavoritos() {
  const user = getUser();
  if (!user) {
    cardsContainer.innerHTML = `
      <p style="text-align:center;color:#888">
        Faça <a href="login.html" style="color:#64cd87">login</a> para ver seus favoritos.
      </p>`;
    return;
  }

  cardsContainer.innerHTML = "<p style='text-align:center;color:#888'>Carregando...</p>";

  try {
    const { recipes } = await apiGetFavorites();
    cardsContainer.innerHTML = "";

    if (!recipes.length) {
      cardsContainer.innerHTML = "<p style='text-align:center;color:#888'>Nenhum favorito ainda.</p>";
      return;
    }

    recipes.forEach(r => cardsContainer.appendChild(buildFavCard(r)));
  } catch (err) {
    cardsContainer.innerHTML = `<p style='text-align:center;color:#e55'>Erro: ${err.message}</p>`;
  }
}

loadFavoritos();
