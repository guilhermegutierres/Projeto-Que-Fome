const Favorite = require("../models/Favorite");

function formatRecipe(r) {
  return {
    id:          r.id_receita,
    title:       r.titulo,
    description: r.descricao,
    calories:    r.media_calorica,
    autor:       r.autor,
    image_url:   null,
  };
}

const favoriteController = {
  async index(req, res, next) {
    try {
      const receitas = await Favorite.findByUser(req.user.id);
      return res.json({ recipes: receitas.map(formatRecipe) });
    } catch (err) { next(err); }
  },

  async ids(req, res, next) {
    try {
      const ids = await Favorite.getIds(req.user.id);
      return res.json({ ids });
    } catch (err) { next(err); }
  },

  async add(req, res, next) {
    try {
      await Favorite.add(req.user.id, req.params.recipe_id);
      return res.json({ favorited: true });
    } catch (err) { next(err); }
  },

  async remove(req, res, next) {
    try {
      await Favorite.remove(req.user.id, req.params.recipe_id);
      return res.json({ favorited: false });
    } catch (err) { next(err); }
  },
};

module.exports = favoriteController;
