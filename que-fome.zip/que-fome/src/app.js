const express = require("express");
const cors    = require("cors");

const authRoutes     = require("./routes/authRoutes");
const recipeRoutes   = require("./routes/recipeRoutes");
const favoriteRoutes = require("./routes/favoriteRoutes");
const commentRoutes  = require("./routes/commentRoutes");
const ratingRoutes   = require("./routes/ratingRoutes");
const errorMiddleware = require("./middlewares/errorMiddleware");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/auth",      authRoutes);
app.use("/api/recipes",   recipeRoutes);
app.use("/api/favorites", favoriteRoutes);
app.use("/api/comments",  commentRoutes);
app.use("/api/ratings",   ratingRoutes);

app.get("/", (_req, res) => res.json({ status: "ok", app: "Que Fome! API" }));

app.use(errorMiddleware);

module.exports = app;
