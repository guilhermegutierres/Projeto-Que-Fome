const db = require("../config/database");

const Favorite = {
  async findByUser(id_usuario) {
    const [rows] = await db.query(
      `SELECT r.*, u.nome_usuario AS autor
       FROM receita r
       INNER JOIN favorito f ON f.id_receita = r.id_receita
       LEFT  JOIN usuario  u ON u.id_usuario = r.id_usuario_autor
       WHERE f.id_usuario = ?
       ORDER BY f.data_marcacao DESC`,
      [id_usuario]
    );
    return rows;
  },

  async add(id_usuario, id_receita) {
    try {
      await db.query(
        "INSERT INTO favorito (id_usuario, id_receita, data_marcacao) VALUES (?, ?, CURDATE())",
        [id_usuario, id_receita]
      );
      return true;
    } catch (err) {
      if (err.code === "ER_DUP_ENTRY") return false;
      throw err;
    }
  },

  async remove(id_usuario, id_receita) {
    const [r] = await db.query(
      "DELETE FROM favorito WHERE id_usuario = ? AND id_receita = ?",
      [id_usuario, id_receita]
    );
    return r.affectedRows > 0;
  },

  async isOwner(id_usuario, id_receita) {
    const [rows] = await db.query(
      "SELECT 1 FROM favorito WHERE id_usuario = ? AND id_receita = ?",
      [id_usuario, id_receita]
    );
    return rows.length > 0;
  },

  async getIds(id_usuario) {
    const [rows] = await db.query(
      "SELECT id_receita FROM favorito WHERE id_usuario = ?",
      [id_usuario]
    );
    return rows.map(r => r.id_receita);
  },
};

module.exports = Favorite;
