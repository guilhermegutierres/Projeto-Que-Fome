const jwt  = require("jsonwebtoken");
const User = require("../models/User");

const authController = {
  async register(req, res, next) {
    try {
      // Frontend envia { name, email, password }
      const { name, email, password } = req.body;
      if (!name || !email || !password)
        return res.status(400).json({ error: "Campos obrigatórios: name, email, password" });

      const user = await User.create({
        nome_usuario: name,
        email,
        senha: password,
      });
      return res.status(201).json({ user });
    } catch (err) {
      if (err.code === "ER_DUP_ENTRY")
        return res.status(409).json({ error: "Usuário ou e-mail já cadastrado" });
      next(err);
    }
  },

  async login(req, res, next) {
    try {
      const { email, password } = req.body;

      const user = await User.findByEmail(email);
      if (!user) return res.status(401).json({ error: "Credenciais inválidas" });

      const valid = await User.comparePassword(password, user.senha);
      if (!valid) return res.status(401).json({ error: "Credenciais inválidas" });

      const token = jwt.sign(
        { id: user.id_usuario, email: user.email },
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
      );

      return res.json({
        token,
        user: {
          id:    user.id_usuario,
          name:  user.nome_usuario,
          email: user.email,
        },
      });
    } catch (err) { next(err); }
  },

  async me(req, res, next) {
    try {
      const u = await User.findById(req.user.id);
      if (!u) return res.status(404).json({ error: "Usuário não encontrado" });
      return res.json({
        user: { id: u.id_usuario, name: u.nome_usuario, email: u.email },
      });
    } catch (err) { next(err); }
  },

  async forgotPassword(req, res, next) {
    try {
      const { email } = req.body;
      const user = await User.findByEmail(email);
      if (!user)
        return res.json({ message: "Se o e-mail existir, você receberá as instruções." });

      const resetToken = jwt.sign(
        { id: user.id_usuario, type: "reset" },
        process.env.JWT_SECRET,
        { expiresIn: "1h" }
      );
      console.log(`🔑 Reset token para ${email}: ${resetToken}`);
      return res.json({ message: "Se o e-mail existir, você receberá as instruções." });
    } catch (err) { next(err); }
  },
};

module.exports = authController;
