const db = require("../config/database");

const Recipe = {
  async findAll({ search, limit = 20, offset = 0 } = {}) {
    let sql = `
      SELECT r.*, u.nome_usuario AS autor
      FROM receita r
      LEFT JOIN usuario u ON u.id_usuario = r.id_usuario_autor
      WHERE 1=1
    `;
    const params = [];

    if (search) {
      sql += " AND (r.titulo LIKE ? OR r.descricao LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += " ORDER BY r.data_publicacao DESC LIMIT ? OFFSET ?";
    params.push(Number(limit), Number(offset));

    const [rows] = await db.query(sql, params);
    return rows;
  },

  async findById(id) {
    const [[receita]] = await db.query(
      `SELECT r.*, u.nome_usuario AS autor
       FROM receita r
       LEFT JOIN usuario u ON u.id_usuario = r.id_usuario_autor
       WHERE r.id_receita = ?`,
      [id]
    );
    if (!receita) return null;

    const [ingredientes] = await db.query(
      `SELECT i.id_ingrediente, i.nome, i.calorias_por_unidade,
              c.quantidade, c.unidade_medida
       FROM composicao_receita c
       INNER JOIN ingrediente i ON i.id_ingrediente = c.id_ingrediente
       WHERE c.id_receita = ?`,
      [id]
    );

    // Média de avaliações
    const [[stats]] = await db.query(
      "SELECT AVG(nota) AS media, COUNT(*) AS total FROM avaliacao WHERE id_receita = ?",
      [id]
    );

    return {
      ...receita,
      ingredientes,
      avaliacao: {
        media: stats.media ? Number(Number(stats.media).toFixed(1)) : null,
        total: stats.total,
      },
    };
  },

  async create({ titulo, descricao, modo_preparo, media_calorica, id_usuario_autor }) {
    const [r] = await db.query(
      `INSERT INTO receita (titulo, descricao, modo_preparo, data_publicacao, media_calorica, id_usuario_autor)
       VALUES (?, ?, ?, CURDATE(), ?, ?)`,
      [titulo, descricao, modo_preparo, media_calorica, id_usuario_autor]
    );
    return r.insertId;
  },

  async addIngrediente(id_receita, { id_ingrediente, quantidade, unidade_medida }) {
    await db.query(
      `INSERT IGNORE INTO composicao_receita (id_receita, id_ingrediente, quantidade, unidade_medida)
       VALUES (?, ?, ?, ?)`,
      [id_receita, id_ingrediente, quantidade, unidade_medida]
    );
  },

  async delete(id) {
    // Deleta dependências primeiro
    await db.query("DELETE FROM composicao_receita WHERE id_receita = ?", [id]);
    await db.query("DELETE FROM comentario WHERE id_receita = ?",         [id]);
    await db.query("DELETE FROM avaliacao  WHERE id_receita = ?",          [id]);
    await db.query("DELETE FROM favorito   WHERE id_receita = ?",          [id]);
    const [r] = await db.query("DELETE FROM receita WHERE id_receita = ?", [id]);
    return r.affectedRows > 0;
  },
};

module.exports = Recipe;
