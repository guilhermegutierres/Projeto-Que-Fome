const db = require("../config/database");

const Comment = {
  async findByRecipe(id_receita) {
    const [rows] = await db.query(
      `SELECT c.*, u.nome_usuario
       FROM comentario c
       INNER JOIN usuario u ON u.id_usuario = c.id_usuario
       WHERE c.id_receita = ?
       ORDER BY c.data_hora DESC`,
      [id_receita]
    );
    return rows;
  },

  async create({ texto_comentario, id_usuario, id_receita }) {
    const [r] = await db.query(
      `INSERT INTO comentario (texto_comentario, data_hora, id_usuario, id_receita)
       VALUES (?, NOW(), ?, ?)`,
      [texto_comentario, id_usuario, id_receita]
    );
    return r.insertId;
  },

  async delete(id_comentario, id_usuario) {
    const [r] = await db.query(
      "DELETE FROM comentario WHERE id_comentario = ? AND id_usuario = ?",
      [id_comentario, id_usuario]
    );
    return r.affectedRows > 0;
  },
};

module.exports = Comment;
