const router = require("express").Router();
const c      = require("../controllers/commentController");
const { requireAuth } = require("../middlewares/authMiddleware");

router.get("/:recipe_id",        c.index);
router.post("/:recipe_id",       requireAuth, c.create);
router.delete("/:id",            requireAuth, c.destroy);

module.exports = router;
