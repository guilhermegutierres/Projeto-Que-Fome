const Rating = require("../models/Rating");

const ratingController = {
  async get(req, res, next) {
    try {
      const stats = await Rating.getForRecipe(req.params.recipe_id);
      return res.json(stats);
    } catch (err) { next(err); }
  },

  async myRating(req, res, next) {
    try {
      const nota = await Rating.getUserRating(req.user.id, req.params.recipe_id);
      return res.json({ nota });
    } catch (err) { next(err); }
  },

  async rate(req, res, next) {
    try {
      const { nota } = req.body;
      if (!nota || nota < 1 || nota > 5)
        return res.status(400).json({ error: "Nota deve ser um número entre 1 e 5" });

      await Rating.upsert({
        id_usuario: req.user.id,
        id_receita: req.params.recipe_id,
        nota,
      });
      return res.json({ message: "Avaliação registrada" });
    } catch (err) { next(err); }
  },
};

module.exports = ratingController;
