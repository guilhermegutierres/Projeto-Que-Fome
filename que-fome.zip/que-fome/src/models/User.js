const db     = require("../config/database");
const bcrypt = require("bcryptjs");

const User = {
  async create({ nome_usuario, email, senha }) {
    const hashed = await bcrypt.hash(senha, 10);
    const [r] = await db.query(
      "INSERT INTO usuario (nome_usuario, email, senha) VALUES (?, ?, ?)",
      [nome_usuario, email, hashed]
    );
    return { id_usuario: r.insertId, nome_usuario, email };
  },

  async findByEmail(email) {
    const [rows] = await db.query("SELECT * FROM usuario WHERE email = ?", [email]);
    return rows[0];
  },

  async findById(id) {
    const [rows] = await db.query(
      "SELECT id_usuario, nome_usuario, email FROM usuario WHERE id_usuario = ?",
      [id]
    );
    return rows[0];
  },

  async updatePassword(id, novaSenha) {
    const hashed = await bcrypt.hash(novaSenha, 10);
    await db.query("UPDATE usuario SET senha = ? WHERE id_usuario = ?", [hashed, id]);
  },

  comparePassword(plain, hashed) {
    return bcrypt.compare(plain, hashed);
  },
};

module.exports = User;
