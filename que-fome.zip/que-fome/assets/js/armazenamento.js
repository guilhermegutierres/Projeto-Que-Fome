const API_BASE = "http://localhost:3000/api";
 
// Placeholder SVG inline (mostrado quando receita não tem imagem)
const PLACEHOLDER_IMG =
  "data:image/svg+xml;utf8," + encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 300 170'>
       <rect width='300' height='170' fill='#e9e8e7'/>
       <text x='50%' y='52%' text-anchor='middle' dominant-baseline='middle' font-size='56'>🍽️</text>
     </svg>`
  );
 
// ================= SESSÃO =================
function getToken() { return localStorage.getItem("qf_token"); }
function getUser()  { const u = localStorage.getItem("qf_user"); return u ? JSON.parse(u) : null; }
function saveSession(token, user) {
  localStorage.setItem("qf_token", token);
  localStorage.setItem("qf_user", JSON.stringify(user));
}
function clearSession() {
  localStorage.removeItem("qf_token");
  localStorage.removeItem("qf_user");
}
 
// ================= FETCH =================
async function apiFetch(path, opts = {}) {
  const token = getToken();
  const headers = { "Content-Type": "application/json", ...opts.headers };
  if (token) headers["Authorization"] = `Bearer ${token}`;
 
  const res  = await fetch(`${API_BASE}${path}`, { ...opts, headers });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Erro na requisição");
  return data;
}
 
// ================= AUTH =================
async function apiLogin(email, password) {
  const data = await apiFetch("/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
  saveSession(data.token, data.user);
  return data;
}
 
async function apiRegister(name, email, password) {
  return apiFetch("/auth/register", {
    method: "POST",
    body: JSON.stringify({ name, email, password }),
  });
}
 
async function apiForgotPassword(email) {
  return apiFetch("/auth/forgot-password", {
    method: "POST",
    body: JSON.stringify({ email }),
  });
}
 
// ================= RECEITAS =================
async function apiGetRecipes(params = {}) {
  const qs = new URLSearchParams(params).toString();
  return apiFetch(`/recipes${qs ? "?" + qs : ""}`);
}
async function apiGetRecipe(id) { return apiFetch(`/recipes/${id}`); }
 
// ================= FAVORITOS =================
async function apiGetFavorites()   { return apiFetch("/favorites"); }
async function apiGetFavoriteIds() {
  if (!getToken()) return { ids: [] };
  return apiFetch("/favorites/ids");
}
async function apiToggleFavorite(recipeId, isFavorite) {
  if (!getToken()) { window.location.href = "login.html"; return; }
  const method = isFavorite ? "DELETE" : "POST";
  return apiFetch(`/favorites/${recipeId}`, { method });
}
 
// ================= COMENTÁRIOS =================
async function apiGetComments(recipeId) { return apiFetch(`/comments/${recipeId}`); }
async function apiAddComment(recipeId, texto) {
  return apiFetch(`/comments/${recipeId}`, {
    method: "POST",
    body: JSON.stringify({ texto_comentario: texto }),
  });
}
 
// ================= AVALIAÇÕES =================
async function apiGetRating(recipeId)  { return apiFetch(`/ratings/${recipeId}`); }
async function apiRate(recipeId, nota) {
  return apiFetch(`/ratings/${recipeId}`, {
    method: "POST",
    body: JSON.stringify({ nota }),
  });
}