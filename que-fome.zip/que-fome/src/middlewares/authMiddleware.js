const jwt = require("jsonwebtoken");

const requireAuth = (req, res, next) => {
  const h = req.headers.authorization;
  if (!h?.startsWith("Bearer "))
    return res.status(401).json({ error: "Token não fornecido" });
  try {
    req.user = jwt.verify(h.split(" ")[1], process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Token inválido ou expirado" });
  }
};

const optionalAuth = (req, _res, next) => {
  const h = req.headers.authorization;
  if (h?.startsWith("Bearer ")) {
    try { req.user = jwt.verify(h.split(" ")[1], process.env.JWT_SECRET); } catch {}
  }
  next();
};

module.exports = { requireAuth, optionalAuth };
