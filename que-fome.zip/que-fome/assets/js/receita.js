// ================= RECEITA =================
const container = document.getElementById("receita-container");

async function loadReceita() {
  const params   = new URLSearchParams(window.location.search);
  const recipeId = params.get("id");

  if (!recipeId) {
    container.innerHTML = "<p>Receita não encontrada.</p>";
    return;
  }

  try {
    const { recipe } = await apiGetRecipe(recipeId);

    const half = Math.ceil(recipe.ingredients.length / 2);
    const col1 = recipe.ingredients.slice(0, half);
    const col2 = recipe.ingredients.slice(half);

    const renderCol = items => items
      .map(i => `<li><strong>${i.quantity}</strong> de ${i.name}</li>`)
      .join("");

    const renderSteps = steps => steps
      .map(s => `<li class="passo">${s.description}</li>`)
      .join("");

    const stars = recipe.avaliacao?.media
      ? "⭐".repeat(Math.round(recipe.avaliacao.media))
      : "";

    container.innerHTML = `
      <h1>${recipe.title}</h1>

      <div class="info">
        ${recipe.autor ? `<p>👨‍🍳 ${recipe.autor}</p>` : "<p></p>"}
        ${recipe.calories ? `<p>🔥 ${recipe.calories} kcal</p>` : "<p></p>"}
        ${recipe.avaliacao?.media
          ? `<p>${stars} ${recipe.avaliacao.media} (${recipe.avaliacao.total})</p>`
          : "<p>Sem avaliações</p>"}
      </div>

      <p class="descricao">${recipe.description || ""}</p>

      <h2 style="margin-top:30px">Ingredientes</h2>
      <div class="ingredientes-container">
        <div class="coluna"><ul>${renderCol(col1)}</ul></div>
        ${col2.length ? `<div class="coluna"><ul>${renderCol(col2)}</ul></div>` : ""}
      </div>

      <h2>Modo de preparo</h2>
      <ol>${renderSteps(recipe.steps)}</ol>

      <button
        class="btn btn-fav ${recipe.isFavorite ? "active" : ""}"
        id="btn-fav-receita"
        style="margin:20px auto;display:inline-flex;gap:8px;align-items:center"
      >
        <span class="heart">
          <i class="${recipe.isFavorite ? "ri-heart-fill" : "ri-heart-line"}"></i>
        </span>
        <span class="txt">${recipe.isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos"}</span>
      </button>

      <!-- AVALIAR -->
      <div id="rating-area" style="margin:30px 0;text-align:center">
        <h3 style="margin-bottom:10px">Avaliar esta receita</h3>
        <div id="stars" style="font-size:28px;cursor:pointer;user-select:none">
          ${[1,2,3,4,5].map(n => `<span data-nota="${n}">☆</span>`).join(" ")}
        </div>
      </div>

      <!-- COMENTÁRIOS -->
      <div style="margin-top:40px;text-align:left">
        <h2 style="text-align:center">Comentários</h2>
        <div id="comentarios-lista" style="margin:20px 0"></div>
        <div id="novo-comentario-area"></div>
      </div>
    `;

    // ================= FAVORITO =================
    document.getElementById("btn-fav-receita").addEventListener("click", async () => {
      const btn   = document.getElementById("btn-fav-receita");
      const isNow = btn.classList.contains("active");
      try {
        await apiToggleFavorite(recipe.id, isNow);
        btn.classList.toggle("active");
        btn.querySelector("i").className  = isNow ? "ri-heart-line" : "ri-heart-fill";
        btn.querySelector(".txt").textContent = isNow
          ? "Adicionar aos favoritos"
          : "Remover dos favoritos";
      } catch (err) { alert(err.message); }
    });

    // ================= AVALIAÇÃO =================
    const starsDiv = document.getElementById("stars");
    starsDiv.querySelectorAll("span").forEach(star => {
      star.addEventListener("click", async () => {
        if (!getUser()) {
          alert("Faça login para avaliar.");
          return;
        }
        const nota = Number(star.dataset.nota);
        try {
          await apiRate(recipe.id, nota);
          // Atualiza visual
          starsDiv.querySelectorAll("span").forEach((s, i) => {
            s.textContent = (i + 1) <= nota ? "★" : "☆";
          });
          alert("Avaliação registrada!");
        } catch (err) { alert(err.message); }
      });
    });

    // ================= COMENTÁRIOS =================
    await loadComentarios(recipe.id);
    renderNovoComentario(recipe.id);

    document.title = `${recipe.title} - Que Fome!`;
  } catch (err) {
    container.innerHTML = `<p>Erro ao carregar receita: ${err.message}</p>`;
  }
}

async function loadComentarios(recipeId) {
  const lista = document.getElementById("comentarios-lista");
  try {
    const { comments } = await apiGetComments(recipeId);

    if (!comments.length) {
      lista.innerHTML = "<p style='color:#888;text-align:center'>Nenhum comentário ainda.</p>";
      return;
    }

    lista.innerHTML = comments.map(c => `
      <div style="background:#f5f5f5;padding:14px;border-radius:10px;margin-bottom:10px">
        <strong>${c.nome_usuario}</strong>
        <span style="color:#888;font-size:12px"> · ${new Date(c.data_hora).toLocaleString("pt-BR")}</span>
        <p style="margin:6px 0 0">${c.texto_comentario}</p>
      </div>
    `).join("");
  } catch (err) {
    lista.innerHTML = `<p style='color:#e55'>Erro: ${err.message}</p>`;
  }
}

function renderNovoComentario(recipeId) {
  const area = document.getElementById("novo-comentario-area");

  if (!getUser()) {
    area.innerHTML = `
      <p style="text-align:center;color:#888">
        <a href="login.html" style="color:#64cd87">Faça login</a> para comentar.
      </p>`;
    return;
  }

  area.innerHTML = `
    <textarea id="novo-comentario" placeholder="Deixe seu comentário..."
      style="width:100%;padding:12px;border-radius:10px;border:1px solid #ddd;
             font-family:inherit;font-size:14px;min-height:80px"></textarea>
    <button class="btn" id="btn-comentar" style="margin-top:10px">Enviar comentário</button>
  `;

  document.getElementById("btn-comentar").addEventListener("click", async () => {
    const texto = document.getElementById("novo-comentario").value.trim();
    if (!texto) return alert("Escreva um comentário antes de enviar.");
    try {
      await apiAddComment(recipeId, texto);
      document.getElementById("novo-comentario").value = "";
      await loadComentarios(recipeId);
    } catch (err) { alert(err.message); }
  });
}

loadReceita();
