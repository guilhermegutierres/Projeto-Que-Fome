const Recipe     = require("../models/Recipe");
const Favorite   = require("../models/Favorite");
const Ingredient = require("../models/Ingredient");

// Converte receita do BD (pt-br) para o formato que o frontend espera
function formatRecipe(r, isFavorite = false) {
  return {
    id:           r.id_receita,
    title:        r.titulo,
    description:  r.descricao,
    modo_preparo: r.modo_preparo,
    calories:     r.media_calorica,
    autor:        r.autor,
    image_url:    null,              // esquema não tem imagem
    created_at:   r.data_publicacao,
    isFavorite,
  };
}

const recipeController = {
  async index(req, res, next) {
    try {
      const { q, limit, offset } = req.query;
      const receitas = await Recipe.findAll({ search: q, limit, offset });

      let favoriteIds = [];
      if (req.user) favoriteIds = await Favorite.getIds(req.user.id);

      const recipes = receitas.map(r =>
        formatRecipe(r, favoriteIds.includes(r.id_receita))
      );
      return res.json({ recipes });
    } catch (err) { next(err); }
  },

  async show(req, res, next) {
    try {
      const r = await Recipe.findById(req.params.id);
      if (!r) return res.status(404).json({ error: "Receita não encontrada" });

      let isFavorite = false;
      if (req.user) isFavorite = await Favorite.isOwner(req.user.id, r.id_receita);

      // Transforma modo_preparo em array de passos (separados por \n)
      const steps = (r.modo_preparo || "")
        .split("\n")
        .map(s => s.trim())
        .filter(s => s.length > 0)
        .map((description, i) => ({ step_order: i + 1, description }));

      const ingredients = r.ingredientes.map(i => ({
        name:     i.nome,
        quantity: `${i.quantidade}${i.unidade_medida ? " " + i.unidade_medida : ""}`,
        calorias_por_unidade: i.calorias_por_unidade,
      }));

      return res.json({
        recipe: {
          ...formatRecipe(r, isFavorite),
          ingredients,
          steps,
          avaliacao: r.avaliacao,
        },
      });
    } catch (err) { next(err); }
  },

  async create(req, res, next) {
    try {
      const { title, description, modo_preparo, calories, ingredients } = req.body;
      if (!title || !modo_preparo)
        return res.status(400).json({ error: "Campos obrigatórios: title, modo_preparo" });

      const id_receita = await Recipe.create({
        titulo:           title,
        descricao:        description,
        modo_preparo,
        media_calorica:   calories,
        id_usuario_autor: req.user.id,
      });

      if (Array.isArray(ingredients)) {
        for (const ing of ingredients) {
          const id_ingrediente = await Ingredient.findOrCreate(
            ing.name,
            ing.calorias_por_unidade
          );
          await Recipe.addIngrediente(id_receita, {
            id_ingrediente,
            quantidade:     ing.quantidade     || 1,
            unidade_medida: ing.unidade_medida || "un",
          });
        }
      }

      const r = await Recipe.findById(id_receita);
      return res.status(201).json({ recipe: formatRecipe(r) });
    } catch (err) { next(err); }
  },

  async destroy(req, res, next) {
    try {
      const ok = await Recipe.delete(req.params.id);
      if (!ok) return res.status(404).json({ error: "Receita não encontrada" });
      return res.json({ message: "Receita removida" });
    } catch (err) { next(err); }
  },
};

module.exports = recipeController;
