const db = require("../config/database");

const Ingredient = {
  async findAll() {
    const [rows] = await db.query("SELECT * FROM ingrediente ORDER BY nome");
    return rows;
  },

  async findByName(nome) {
    const [rows] = await db.query("SELECT * FROM ingrediente WHERE nome = ?", [nome]);
    return rows[0];
  },

  async findOrCreate(nome, calorias_por_unidade = null) {
    const exists = await Ingredient.findByName(nome);
    if (exists) return exists.id_ingrediente;

    const [r] = await db.query(
      "INSERT INTO ingrediente (nome, calorias_por_unidade) VALUES (?, ?)",
      [nome, calorias_por_unidade]
    );
    return r.insertId;
  },
};

module.exports = Ingredient;
