const router = require("express").Router();
const c      = require("../controllers/ratingController");
const { requireAuth } = require("../middlewares/authMiddleware");

router.get("/:recipe_id",       c.get);
router.get("/:recipe_id/me",    requireAuth, c.myRating);
router.post("/:recipe_id",      requireAuth, c.rate);

module.exports = router;
