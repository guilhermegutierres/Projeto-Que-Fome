// ================= MAIN - INDEX =================
const cardsContainer = document.querySelector(".cards");
const searchInput    = document.querySelector(".search input");

let favoriteIds = [];

// ================= CARD =================
function buildCard(recipe) {
  const isFav = favoriteIds.includes(recipe.id);
  const card  = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <img src="${recipe.image_url || PLACEHOLDER_IMG}" alt="${recipe.title}">
    <div>
      <h2>${recipe.title}</h2>
      <p>${recipe.description || ""}</p>
      <div class="card-actions">
        <button class="btn" onclick="verReceita(${recipe.id})">Ver receita</button>
        <button class="btn btn-fav ${isFav ? "active" : ""}" data-id="${recipe.id}">
          <span class="heart"><i class="${isFav ? "ri-heart-fill" : "ri-heart-line"}"></i></span>
          ${isFav ? "Salvo" : "Favoritar"}
        </button>
      </div>
    </div>
  `;

  card.querySelector(".btn-fav").addEventListener("click", async (e) => {
    e.stopPropagation();
    const btn  = e.currentTarget;
    const id   = Number(btn.dataset.id);
    const wasFav = btn.classList.contains("active");

    try {
      await apiToggleFavorite(id, wasFav);
      if (wasFav) {
        favoriteIds = favoriteIds.filter(f => f !== id);
        btn.classList.remove("active");
        btn.innerHTML = `<span class="heart"><i class="ri-heart-line"></i></span> Favoritar`;
      } else {
        favoriteIds.push(id);
        btn.classList.add("active");
        btn.innerHTML = `<span class="heart"><i class="ri-heart-fill"></i></span> Salvo`;
      }
    } catch (err) { alert(err.message); }
  });

  return card;
}

function verReceita(id) {
  window.location.href = `receita.html?id=${id}`;
}

// ================= CARREGAR RECEITAS =================
async function loadRecipes(params = {}) {
  cardsContainer.innerHTML = "<p style='text-align:center;color:#888'>Carregando...</p>";
  try {
    const { ids } = await apiGetFavoriteIds();
    favoriteIds = ids;

    const { recipes } = await apiGetRecipes(params);
    cardsContainer.innerHTML = "";

    if (!recipes.length) {
      cardsContainer.innerHTML = "<p style='text-align:center;color:#888'>Nenhuma receita encontrada.</p>";
      return;
    }

    recipes.forEach(r => cardsContainer.appendChild(buildCard(r)));
  } catch (err) {
    cardsContainer.innerHTML = `<p style='text-align:center;color:#e55'>Erro: ${err.message}</p>`;
  }
}

// ================= BUSCA =================
if (searchInput) {
  let debounce;
  searchInput.addEventListener("input", () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      const q = searchInput.value.trim();
      loadRecipes(q ? { q } : {});
    }, 400);
  });
}

// ================= FILTRO NAVBAR (busca pela subcategoria no título) =================
document.querySelectorAll(".dropdown-content a").forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();
    const termo = link.textContent.trim();
    loadRecipes({ q: termo });
  });
});

// ================= INIT =================
loadRecipes();
