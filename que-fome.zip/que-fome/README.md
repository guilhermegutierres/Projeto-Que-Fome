## 🍽️ Que Fome! — API + Frontend

App de receitas com MySQL, autenticação JWT, favoritos, comentários e avaliações.

## 🚀 Como rodar

```bash
# 1. Instalar dependências
npm install

# 2. Configurar ambiente
cp .env.example .env
# Preencha DB_PASSWORD (senha do seu MySQL) e JWT_SECRET

# 3. Criar o banco no MySQL Workbench
#    CREATE DATABASE sistema_receitas;

# 4. Criar as tabelas (ou rode o SQL completo no Workbench)
npm run migrate

# 5. Popular com receitas de exemplo
npm run seed

# 6. Iniciar servidor
npm run dev
```

Depois abra `index.html` no navegador (pode usar a extensão "Live Server" no VSCode).

**Usuário de teste criado pelo seed:**
- Email: `chef@quefome.com`
- Senha: `123456`

## 📁 Estrutura

```
que-fome/
├── *.html                    # Páginas do frontend
├── assets/
│   ├── css/                  # CSS (main, auth, receita)
│   ├── js/                   # Frontend conectado à API
│   └── img/                  # Imagens das receitas
├── server.js
└── src/
    ├── app.js
    ├── config/
    │   ├── database.js
    │   ├── migrate.js        # Cria as tabelas
    │   └── seed.js           # Popula receitas de exemplo
    ├── controllers/
    ├── middlewares/
    ├── models/
    │   ├── User.js           # tabela usuario
    │   ├── Recipe.js         # tabela receita
    │   ├── Ingredient.js     # tabela ingrediente
    │   ├── Favorite.js       # tabela favorito
    │   ├── Comment.js        # tabela comentario
    │   └── Rating.js         # tabela avaliacao
    ├── routes/
    └── services/
        └── tacoService.js
```

## 📌 Endpoints da API

### Auth
| Método | Rota                       |
|--------|----------------------------|
| POST   | /api/auth/register         |
| POST   | /api/auth/login            |
| POST   | /api/auth/forgot-password  |
| GET    | /api/auth/me               |

### Receitas
| Método | Rota                |
|--------|---------------------|
| GET    | /api/recipes        |
| GET    | /api/recipes?q=     |
| GET    | /api/recipes/:id    |
| POST   | /api/recipes        |
| DELETE | /api/recipes/:id    |

### Favoritos
| Método | Rota                    |
|--------|-------------------------|
| GET    | /api/favorites          |
| GET    | /api/favorites/ids      |
| POST   | /api/favorites/:id      |
| DELETE | /api/favorites/:id      |

### Comentários
| Método | Rota                     |
|--------|--------------------------|
| GET    | /api/comments/:recipe_id |
| POST   | /api/comments/:recipe_id |
| DELETE | /api/comments/:id        |

### Avaliações
| Método | Rota                        |
|--------|-----------------------------|
| GET    | /api/ratings/:recipe_id     |
| GET    | /api/ratings/:recipe_id/me  |
| POST   | /api/ratings/:recipe_id     |

## 📝 Mapeamento Banco ↔ Frontend

| Banco (pt-br)        | API / Frontend (en) |
|----------------------|---------------------|
| `usuario`            | users               |
| `nome_usuario`       | name                |
| `senha`              | password            |
| `receita`            | recipes             |
| `titulo`             | title               |
| `descricao`          | description         |
| `media_calorica`     | calories            |
| `id_usuario_autor`   | autor               |
| `favorito`           | favorites           |

Os controllers fazem essa tradução automaticamente.
