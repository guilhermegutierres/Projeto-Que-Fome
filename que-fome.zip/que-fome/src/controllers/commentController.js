const Comment = require("../models/Comment");

const commentController = {
  async index(req, res, next) {
    try {
      const comments = await Comment.findByRecipe(req.params.recipe_id);
      return res.json({ comments });
    } catch (err) { next(err); }
  },

  async create(req, res, next) {
    try {
      const { texto_comentario } = req.body;
      if (!texto_comentario)
        return res.status(400).json({ error: "Texto do comentário é obrigatório" });

      const id = await Comment.create({
        texto_comentario,
        id_usuario: req.user.id,
        id_receita: req.params.recipe_id,
      });
      return res.status(201).json({ id_comentario: id });
    } catch (err) { next(err); }
  },

  async destroy(req, res, next) {
    try {
      const ok = await Comment.delete(req.params.id, req.user.id);
      if (!ok) return res.status(404).json({ error: "Comentário não encontrado" });
      return res.json({ message: "Comentário removido" });
    } catch (err) { next(err); }
  },
};

module.exports = commentController;
