// ================= ÁREA DO USUÁRIO NO HEADER =================
(function initUserArea() {
  const userArea = document.getElementById("user-area");
  if (!userArea) return;

  const user = getUser();

  if (user) {
    userArea.innerHTML = `👤 ${user.name}`;
    userArea.title = "Clique para sair";
    userArea.addEventListener("click", () => {
      if (confirm("Deseja sair?")) {
        clearSession();
        window.location.href = "index.html";
      }
    });
  } else {
    userArea.textContent = "Entrar";
    userArea.addEventListener("click", () => {
      window.location.href = "login.html";
    });
  }
})();
