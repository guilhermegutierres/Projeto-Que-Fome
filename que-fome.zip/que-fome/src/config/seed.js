require("dotenv").config();
const bcrypt = require("bcryptjs");
const db     = require("./database");;

const receitas = [
  {
    titulo: "Macarrão ao Alho e Óleo",
    descricao: "Clássico italiano simples e delicioso, pronto em minutos.",
    modo_preparo: [
      "Cozinhe o espaguete em água com sal até ficar al dente.",
      "Enquanto isso, fatie o alho e refogue no azeite em fogo baixo até dourar.",
      "Adicione pimenta calabresa e misture.",
      "Escorra a massa e misture com o azeite de alho.",
      "Finalize com salsinha picada e sirva imediatamente.",
    ].join("\n"),
    media_calorica: 380,
    ingredientes: [
      { nome: "Espaguete",         quantidade: 200, unidade_medida: "g",   calorias_por_unidade: 1.3 },
      { nome: "Alho",              quantidade: 6,   unidade_medida: "un",  calorias_por_unidade: 4 },
      { nome: "Azeite",            quantidade: 4,   unidade_medida: "clh", calorias_por_unidade: 40 },
      { nome: "Pimenta calabresa", quantidade: 1,   unidade_medida: "clh", calorias_por_unidade: 2 },
      { nome: "Sal",               quantidade: 1,   unidade_medida: "clh", calorias_por_unidade: 0 },
      { nome: "Salsinha",          quantidade: 1,   unidade_medida: "clh", calorias_por_unidade: 1 },
    ],
  },
  {
    titulo: "Salada Caesar",
    descricao: "Salada refrescante com croutons crocantes e molho Caesar caseiro.",
    modo_preparo: [
      "Prepare o molho misturando maionese, suco de limão e alho amassado.",
      "Lave e seque as folhas de alface romana.",
      "Rasgue as folhas em pedaços e coloque numa tigela.",
      "Adicione o molho e misture bem.",
      "Finalize com croutons e parmesão ralado.",
    ].join("\n"),
    media_calorica: 210,
    ingredientes: [
      { nome: "Alface romana",            quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 30 },
      { nome: "Croutons",                 quantidade: 1,   unidade_medida: "xíc", calorias_por_unidade: 100 },
      { nome: "Queijo parmesão ralado",   quantidade: 50,  unidade_medida: "g",   calorias_por_unidade: 4.3 },
      { nome: "Maionese",                 quantidade: 3,   unidade_medida: "clh", calorias_por_unidade: 90 },
      { nome: "Suco de limão",            quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 10 },
    ],
  },
  {
    titulo: "Bolo de Cenoura com Chocolate",
    descricao: "O bolo de cenoura mais fofinho com cobertura de chocolate irresistível.",
    modo_preparo: [
      "Bata no liquidificador a cenoura, ovos, óleo e açúcar.",
      "Transfira para uma tigela e adicione a farinha e o fermento, misturando delicadamente.",
      "Despeje numa forma untada e leve ao forno a 180°C por 35-40 minutos.",
      "Para a cobertura: misture chocolate, manteiga e leite numa panela em fogo baixo até engrossar.",
      "Desenforme o bolo ainda quente e cubra com o chocolate.",
    ].join("\n"),
    media_calorica: 320,
    ingredientes: [
      { nome: "Cenoura",            quantidade: 3,   unidade_medida: "un",  calorias_por_unidade: 25 },
      { nome: "Ovo",                quantidade: 3,   unidade_medida: "un",  calorias_por_unidade: 70 },
      { nome: "Óleo",               quantidade: 1,   unidade_medida: "xíc", calorias_por_unidade: 880 },
      { nome: "Açúcar",             quantidade: 2,   unidade_medida: "xíc", calorias_por_unidade: 770 },
      { nome: "Farinha de trigo",   quantidade: 2,   unidade_medida: "xíc", calorias_por_unidade: 400 },
      { nome: "Fermento",           quantidade: 1,   unidade_medida: "clh", calorias_por_unidade: 5 },
      { nome: "Chocolate em pó",    quantidade: 4,   unidade_medida: "clh", calorias_por_unidade: 22 },
    ],
  },
  {
    titulo: "Suco Verde Detox",
    descricao: "Suco energizante cheio de vitaminas para começar bem o dia.",
    modo_preparo: [
      "Lave bem todos os ingredientes.",
      "Corte em pedaços menores para facilitar o processamento.",
      "Bata tudo no liquidificador com a água de coco.",
      "Coe se preferir e sirva gelado.",
    ].join("\n"),
    media_calorica: 85,
    ingredientes: [
      { nome: "Couve",         quantidade: 2,   unidade_medida: "un",  calorias_por_unidade: 10 },
      { nome: "Maçã verde",    quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 52 },
      { nome: "Pepino",        quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 15 },
      { nome: "Gengibre",      quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 5 },
      { nome: "Água de coco",  quantidade: 200, unidade_medida: "ml",  calorias_por_unidade: 0.2 },
      { nome: "Limão",         quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 10 },
    ],
  },
  {
    titulo: "Arroz de Forno",
    descricao: "Arroz cremoso assado com frango e queijo gratinado.",
    modo_preparo: [
      "Misture o arroz cozido com o frango desfiado, milho, ervilha e creme de leite.",
      "Tempere com sal a gosto.",
      "Transfira para um refratário untado.",
      "Cubra com mussarela fatiada.",
      "Leve ao forno a 200°C por 20 minutos ou até o queijo gratinar.",
    ].join("\n"),
    media_calorica: 290,
    ingredientes: [
      { nome: "Arroz cozido",     quantidade: 3,   unidade_medida: "xíc", calorias_por_unidade: 200 },
      { nome: "Frango desfiado",  quantidade: 300, unidade_medida: "g",   calorias_por_unidade: 1.6 },
      { nome: "Creme de leite",   quantidade: 200, unidade_medida: "ml",  calorias_por_unidade: 2 },
      { nome: "Mussarela",        quantidade: 200, unidade_medida: "g",   calorias_por_unidade: 3 },
      { nome: "Milho",            quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 90 },
      { nome: "Ervilha",          quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 80 },
    ],
  },
  {
    titulo: "Sopa Creme de Abóbora",
    descricao: "Sopa aveludada e reconfortante, perfeita para os dias frios.",
    modo_preparo: [
      "Refogue a cebola e o alho no azeite até ficarem macios.",
      "Adicione a abóbora cortada em cubos e o caldo de legumes.",
      "Cozinhe por 20 minutos até a abóbora amolecer.",
      "Bata tudo no liquidificador até obter um creme homogêneo.",
      "Volte ao fogo, adicione o creme de leite e acerte o sal.",
    ].join("\n"),
    media_calorica: 140,
    ingredientes: [
      { nome: "Abóbora",          quantidade: 500, unidade_medida: "g",   calorias_por_unidade: 0.4 },
      { nome: "Cebola",           quantidade: 1,   unidade_medida: "un",  calorias_por_unidade: 40 },
      { nome: "Caldo de legumes", quantidade: 600, unidade_medida: "ml",  calorias_por_unidade: 0.1 },
    ],
  },
];

async function seed() {
  const c = await db.getConnection();
  try {
    // Usuário padrão (autor das receitas)
    const senhaHash = await bcrypt.hash("123456", 10);
    await c.query(
      `INSERT IGNORE INTO usuario (nome_usuario, email, senha) VALUES (?, ?, ?)`,
      ["chef_quefome", "chef@quefome.com", senhaHash]
    );
    const [[autor]] = await c.query(
      "SELECT id_usuario FROM usuario WHERE nome_usuario = ?",
      ["chef_quefome"]
    );

    for (const r of receitas) {
      const [rec] = await c.query(
        `INSERT INTO receita (titulo, descricao, modo_preparo, data_publicacao, media_calorica, id_usuario_autor)
         VALUES (?, ?, ?, CURDATE(), ?, ?)`,
        [r.titulo, r.descricao, r.modo_preparo, r.media_calorica, autor.id_usuario]
      );
      const id_receita = rec.insertId;

      for (const ing of r.ingredientes) {
        // Cria ingrediente se não existe
        let [[existing]] = await c.query(
          "SELECT id_ingrediente FROM ingrediente WHERE nome = ?",
          [ing.nome]
        );
        let id_ingrediente;
        if (existing) {
          id_ingrediente = existing.id_ingrediente;
        } else {
          const [r2] = await c.query(
            "INSERT INTO ingrediente (nome, calorias_por_unidade) VALUES (?, ?)",
            [ing.nome, ing.calorias_por_unidade]
          );
          id_ingrediente = r2.insertId;
        }

        await c.query(
          `INSERT IGNORE INTO composicao_receita (id_receita, id_ingrediente, quantidade, unidade_medida)
           VALUES (?, ?, ?, ?)`,
          [id_receita, id_ingrediente, ing.quantidade, ing.unidade_medida]
        );
      }
    }
    console.log(`✅ ${receitas.length} receitas inseridas com sucesso!`);
    console.log(`👤 Usuário padrão: chef@quefome.com / senha: 123456`);
  } catch (err) {
    console.error("❌ Erro no seed:", err.message);
  } finally {
    c.release();
    process.exit(0);
  }
}

seed();
