import axios from 'axios';

const options = {
  method: 'POST',
  url: 'https://taco-api-br1.p.rapidapi.com/ai/suggest',
  headers: {
    'x-rapidapi-key': '3d3e59df6fmsh54471d523b7f76fp1a53dfjsn85338be76e68',
    'x-rapidapi-host': 'taco-api-br1.p.rapidapi.com',
    'Content-Type': 'application/json'
  },
  data: {
    prompt: 'almoço rico em ferro'
  }
};

try {
	const response = await axios.request(options);
	console.log(response.data);
} catch (error) {
	console.error(error);
}

const axios = require("axios");

const TACO_BASE = "https://taco-food-api.herokuapp.com/api/v1";

const tacoService = {
  async searchFoods(query) {
    const { data } = await axios.get(`${TACO_BASE}/food`, { params: { food: query } });
    return data;
  },

  async getFoodById(id) {
    const { data } = await axios.get(`${TACO_BASE}/food/${id}`);
    return data;
  },

  calcNutrients(food, grams) {
    const r = grams / 100;
    return {
      calories: +((food.energy_kcal || 0) * r).toFixed(2),
      proteins: +((food.protein     || 0) * r).toFixed(2),
      carbs:    +((food.carbohydrate|| 0) * r).toFixed(2),
      fats:     +((food.lipids      || 0) * r).toFixed(2),
    };
  },
};

module.exports = tacoService;
